import 'package:flutter/material.dart';
import 'package:flutter_sound/flutter_sound.dart';
import 'package:permission_handler/permission_handler.dart';
import 'dart:io';
import 'package:path_provider/path_provider.dart';

class VoiceRecordingPage extends StatefulWidget {
  const VoiceRecordingPage({super.key});

  @override
  _VoiceRecordingPageState createState() => _VoiceRecordingPageState();
}

class _VoiceRecordingPageState extends State<VoiceRecordingPage> {
  final FlutterSoundRecorder _recorder = FlutterSoundRecorder();
  final FlutterSoundPlayer _player = FlutterSoundPlayer();
  bool _isRecording = false;
  String? _filePath;
  String? _currentlyPlaying;
  List<Map<String, String>> _recordings = [];

  @override
  void initState() {
    super.initState();
    _initializeRecorder();
  }

  Future<void> _initializeRecorder() async {
    await Permission.microphone.request();
    await Permission.storage.request();
    await _recorder.openRecorder();
    await _player.openPlayer();
  }

  Future<void> _startRecording() async {
    final Directory tempDir = await getApplicationDocumentsDirectory();
    final String path = '${tempDir.path}/recording_${DateTime.now().millisecondsSinceEpoch}.aac';
    await _recorder.startRecorder(toFile: path);
    setState(() {
      _isRecording = true;
      _filePath = path;
    });
  }

  Future<void> _stopRecording() async {
    await _recorder.stopRecorder();
    setState(() {
      _isRecording = false;
    });
    _showSaveDialog();
  }

  Future<void> _playRecording(String path) async {
    if (_currentlyPlaying == path) {
      await _player.stopPlayer();
      setState(() {
        _currentlyPlaying = null;
      });
    } else {
      if (_currentlyPlaying != null) {
        await _player.stopPlayer();
      }
      await _player.startPlayer(fromURI: path);
      setState(() {
        _currentlyPlaying = path;
      });
    }
  }

  void _showSaveDialog() {
    final TextEditingController _labelController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Save Recording"),
          content: TextField(
            controller: _labelController,
            decoration: const InputDecoration(hintText: "Enter label for recording"),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text("Cancel"),
            ),
            TextButton(
              onPressed: () {
                if (_labelController.text.isNotEmpty) {
                  setState(() {
                    _recordings.add({
                      'label': _labelController.text,
                      'path': _filePath!,
                    });
                  });
                  Navigator.of(context).pop();
                }
              },
              child: const Text("Save"),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _recorder.closeRecorder();
    _player.closePlayer();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'VOICE RECORDING',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Color(0xFF003366),
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: Column(
        children: [
          const SizedBox(height: 24),
          Icon(
            _isRecording ? Icons.mic : Icons.mic_none,
            size: 80,
            color: _isRecording ? Colors.red : Colors.grey,
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: _isRecording ? _stopRecording : _startRecording,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueGrey,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
            child: Text(_isRecording ? 'Stop Recording' : 'Start Recording'),
          ),
          const SizedBox(height: 30),
          const Text(
            "Saved Recordings",
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          const SizedBox(height: 10),
          Expanded(
            child: _recordings.isNotEmpty
                ? ListView.builder(
                    itemCount: _recordings.length,
                    itemBuilder: (context, index) {
                      bool isPlaying = _currentlyPlaying == _recordings[index]['path'];
                      return Card(
                        color: isPlaying ? const Color(0xFFE3F2FD) : Colors.white,
                        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        elevation: 3,
                        child: ListTile(
                          leading: IconButton(
                            icon: Icon(isPlaying ? Icons.stop : Icons.play_arrow),
                            color: isPlaying ? Colors.blue : Colors.black87,
                            onPressed: () => _playRecording(_recordings[index]['path']!),
                          ),
                          title: Text(
                            _recordings[index]['label']!,
                            style: TextStyle(color: isPlaying ? Colors.blue : Colors.black87),
                          ),
                          subtitle: const Text("Tap to play/stop"),
                        ),
                      );
                    },
                  )
                : const Center(
                    child: Text(
                      "No recordings available.",
                      style: TextStyle(color: Colors.grey),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
