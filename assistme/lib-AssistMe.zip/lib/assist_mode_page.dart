import 'package:flutter/material.dart';

class AssistModePage extends StatelessWidget {
  const AssistModePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE1F8FF),
      appBar: AppBar(
        title: const Text('Assist Mode'),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: const Center(
        child: Text(
          'Assist Mode (Coming Soon)',
          style: TextStyle(fontSize: 20, color: Color(0xFF002C5F)),
        ),
      ),
    );
  }
}
