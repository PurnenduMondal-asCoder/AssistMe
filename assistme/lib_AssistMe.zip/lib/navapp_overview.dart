import 'package:flutter/material.dart';
// import 'package:lottie/lottie.dart'; // Optional animation

class AboutAppPage extends StatelessWidget {
  const AboutAppPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal[50],
      appBar: AppBar(
        title: const Text('About AssistMe'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 2,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Column(
                children: [
                  // Optional: Lottie animation
                  // Lottie.asset(
                  //   'assets/assist_logo.json',
                  //   height: 100,
                  // ),
                  const SizedBox(height: 8),
                  const Text(
                    'AssistMe',
                    style: TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal,
                    ),
                  ),
                  const Text(
                    'Empowering Accessible Communication',
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),
            _sectionHeader('📝 About AssistMe'),
            _paragraph(
              'AssistMe is a smart assistance platform designed to support individuals with speech, vision, or mobility challenges. It offers intuitive tools for communication—text, voice, and symbol-based—alongside emergency alerts, location sharing, and customizable user profiles.',
            ),

            _sectionHeader('🔧 Key Features'),
            _bullet('Text-Based & Symbol Communication'),
            _bullet('Voice Command and Playback'),
            _bullet('Emergency SMS Alerts with Location'),
            _bullet('Custom User Profiles'),
            _bullet('Secure Cloud Sync'),

            _sectionHeader('👨‍💻 Developers'),
            _developer('Purnendu Mondal', 'purnendumondal389@gmail.com'),
            _developer('Sandipan Sen', 'sandipanbca21@gmail.com'),
            _developer('Jeet Nandi', 'jeetnandi873@gmail.com'),
            _developer('Sanket Gandhi', 'gandhisanketoct@gmail.com'),

            _sectionHeader('📅 Version Info'),
            _paragraph('Version: 1.0.0\nLast Updated: June 5, 2025'),

            _sectionHeader('🏆 Credits & Acknowledgements'),
            _paragraph(
              '• Flutter & Dart\n• Firebase\n• Material Icons\n• Open-source libraries & Flutter Dev Community',
            ),

            const SizedBox(height: 30),
            Center(
              child: Text(
                '© 2025 AssistMe • Built with ❤️ by Mondal_As_Developer',
                style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(top: 24, bottom: 10),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 20,
          fontWeight: FontWeight.w600,
          color: Colors.teal,
        ),
      ),
    );
  }

  Widget _paragraph(String text) {
    return Text(
      text,
      style: const TextStyle(fontSize: 16, height: 1.6),
    );
  }

  Widget _bullet(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          const Icon(Icons.check_circle, size: 18, color: Colors.teal),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }

  Widget _developer(String name, String email) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          const Icon(Icons.account_circle, size: 20, color: Colors.black54),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontSize: 16)),
                Text(email,
                    style: const TextStyle(fontSize: 14, color: Colors.grey)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
