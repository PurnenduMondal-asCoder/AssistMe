import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:android_intent_plus/android_intent.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'main.dart';
import 'assist_mode_page.dart';
import 'login.dart';
import 'profile_page.dart';
import 'navapp_overview.dart';

class PickModePage extends StatefulWidget {
  final bool openDrawer;
  const PickModePage({super.key, this.openDrawer = false});

  @override
  State<PickModePage> createState() => _PickModePageState();
}

class _PickModePageState extends State<PickModePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
  List<String> emergencyNumbers = [];

  @override
  void initState() {
    super.initState();
    _loadEmergencyNumbers();
  }

  Future<void> _loadEmergencyNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      emergencyNumbers = prefs.getStringList('emergencyNumbers') ?? [];
    });
  }

  Future<void> _saveEmergencyNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('emergencyNumbers', emergencyNumbers);
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (widget.openDrawer) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _scaffoldKey.currentState?.openDrawer();
      });
    }
  }

  void _logout(BuildContext context) {
    FirebaseAuth.instance.signOut();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (_) => const Login()),
      (route) => false,
    );
  }

  void _showMessage(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  Future<void> _launchSMS(String number) async {
    final intent = AndroidIntent(
      action: 'android.intent.action.SENDTO',
      data: 'smsto:$number',
      arguments: {
        'sms_body': '🚨 This is an emergency alert. I need help immediately!',
      },
    );

    try {
      await intent.launch();
    } catch (e) {
      _launchWhatsApp(number);
    }
  }

  Future<void> _launchWhatsApp(String number) async {
    final uri = Uri.parse(
      'https://wa.me/$number?text=${Uri.encodeComponent("🚨 This is an emergency alert. I need help immediately!")}',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      _showMessage(context, "Neither SMS nor WhatsApp is available.");
    }
  }

  void _showAddNumberDialog({bool fromEmergency = false}) {
    TextEditingController controller = TextEditingController();
    int? editingIndex;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setStateDialog) {
          void addOrUpdateNumber() {
            final number = controller.text.trim();
            if (number.isEmpty) {
              ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text("Please enter a phone number")));
              return;
            }

            setStateDialog(() {
              if (editingIndex != null) {
                // update existing number
                emergencyNumbers[editingIndex!] = number;
                editingIndex = null;
              } else {
                if (!emergencyNumbers.contains(number)) {
                  emergencyNumbers.add(number);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Number already exists")));
                }
              }
              controller.clear();
            });
          }

          void startEdit(int index) {
            setStateDialog(() {
              editingIndex = index;
              controller.text = emergencyNumbers[index];
            });
          }

          void deleteNumber(int index) {
            setStateDialog(() {
              if (editingIndex == index) {
                editingIndex = null;
                controller.clear();
              }
              emergencyNumbers.removeAt(index);
            });
          }

          return AlertDialog(
            title: const Text('Manage Emergency Numbers'),
            content: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Input field with add/update button
                  TextField(
                    controller: controller,
                    keyboardType: TextInputType.phone,
                    decoration: InputDecoration(
                      hintText: 'Enter phone number',
                      suffixIcon: IconButton(
                        icon: Icon(editingIndex == null ? Icons.add : Icons.check),
                        onPressed: addOrUpdateNumber,
                      ),
                      border: const OutlineInputBorder(),
                    ),
                    onSubmitted: (_) => addOrUpdateNumber(),
                  ),
                  const SizedBox(height: 20),
                  // List of saved numbers below
                  emergencyNumbers.isEmpty
                      ? const Text("No emergency numbers added yet.")
                      : Flexible(
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: emergencyNumbers.length,
                            itemBuilder: (context, index) {
                              final num = emergencyNumbers[index];
                              final isEditing = editingIndex == index;
                              return ListTile(
                                title: Text(num),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      icon: Icon(isEditing ? Icons.close : Icons.edit),
                                      onPressed: () {
                                        if (isEditing) {
                                          setStateDialog(() {
                                            editingIndex = null;
                                            controller.clear();
                                          });
                                        } else {
                                          startEdit(index);
                                        }
                                      },
                                    ),
                                    IconButton(
                                      icon: const Icon(Icons.delete, color: Colors.redAccent),
                                      onPressed: () => deleteNumber(index),
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
                        ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Cancel')),
              ElevatedButton(
                onPressed: () async {
                  if (emergencyNumbers.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Please add at least one number")));
                    return;
                  }
                  await _saveEmergencyNumbers();
                  Navigator.pop(context);
                  setState(() {});
                  if (fromEmergency) {
                    // Launch SMS with first number if emergency triggered
                    _launchSMS(emergencyNumbers.first);
                  }
                },
                child: const Text('Save'),
              ),
            ],
          );
        });
      },
    );
  }

  Widget _customDrawerTile({
    required IconData icon,
    required String label,
    required String subtitle,
    required Color color,
    required Color backgroundColor,
    required VoidCallback onTap,
  }) {
    return Card(
      color: backgroundColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 2,
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: color.withOpacity(0.1),
          child: Icon(icon, color: color),
        ),
        title: Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.black54)),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: const Color(0xFFE6F7FF),
      appBar: AppBar(
        backgroundColor: const Color(0xFF0375F6),
        title: const Text('Start with AssistMe', style: TextStyle(color: Colors.white)),
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 4,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications, color: Colors.white),
            onPressed: () => _showMessage(context, 'No new notifications at the moment.'),
          ),
        ],
      ),
      drawer: FutureBuilder<DocumentSnapshot>(
        future: FirebaseFirestore.instance.collection('users')
            .doc(FirebaseAuth.instance.currentUser?.uid).get(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Drawer(child: Center(child: CircularProgressIndicator()));
          }

          if (!snapshot.hasData || !snapshot.data!.exists) {
            return const Drawer(child: Center(child: Text('User data not found.')));
          }

          final userData = snapshot.data!.data() as Map<String, dynamic>;
          final fullName = userData['name'] ?? 'User';

          return Drawer(
            child: Column(children: [
              Container(
                padding: const EdgeInsets.fromLTRB(16, 40, 16, 24),
                color: const Color(0xFF0375F6),
                child: Row(children: [
                  const CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.white,
                    child: Icon(Icons.person, size: 32, color: Colors.blue),
                  ),
                  const SizedBox(width: 16),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Hello, $fullName',
                          style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                      const SizedBox(height: 4),
                      const Text('Glad to have you onboard.',
                          style: TextStyle(fontSize: 14, color: Colors.white70)),
                    ],
                  )),
                ]),
              ),
              const SizedBox(height: 12),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    _customDrawerTile(
                      icon: Icons.info_outline,
                      label: 'About App',
                      subtitle: 'Overview & Features',
                      color: const Color(0xFF1565C0),
                      backgroundColor: const Color(0xFFD0E8FF),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutAppPage()))
                            .then((_) => Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (_) => const PickModePage(openDrawer: true))));
                      },
                    ),
                    _customDrawerTile(
                      icon: Icons.person_outline,
                      label: 'Profile',
                      subtitle: 'View & Edit Info',
                      color: const Color(0xFF1565C0),
                      backgroundColor: const Color(0xFFF0F8FF),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.push(context, MaterialPageRoute(builder: (_) => const ProfilePage()))
                            .then((_) => Navigator.pushReplacement(context,
                            MaterialPageRoute(builder: (_) => const PickModePage(openDrawer: true))));
                      },
                    ),
                    _customDrawerTile(
                      icon: Icons.logout,
                      label: 'Log Out',
                      subtitle: 'Exit your session',
                      color: Colors.redAccent,
                      backgroundColor: const Color(0xFFFFEBEE),
                      onTap: () => _logout(context),
                    ),
                  ],
                ),
              ),
            ]),
          );
        },
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text('PICK YOUR MODE',
                    style: TextStyle(fontSize: 30, fontWeight: FontWeight.w700, color: Color(0xFF002C5F))),
                const SizedBox(height: 40),
                _buildModeButton(
                  text: 'Assistive Mode',
                  color1: const Color(0xFF42A5F5),
                  color2: const Color(0xFF1E88E5),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AssistModePage())),
                ),
                const SizedBox(height: 20),
                _buildModeButton(
                  text: 'Standard Mode',
                  color1: const Color(0xFF66BB6A),
                  color2: const Color(0xFF43A047),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const HomePage())),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 20),
        child: Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 52,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFFDB3A34),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 6,
                  ),
                  onPressed: () {
                    if (emergencyNumbers.isEmpty) {
                      _showAddNumberDialog(fromEmergency: true);
                    } else {
                      _launchSMS(emergencyNumbers.first);
                    }
                  },
                  child: const Text('EMERGENCY', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Container(
              height: 52,
              width: 52,
              decoration: BoxDecoration(
                color: const Color(0xFF1565C0),
                borderRadius: BorderRadius.circular(16),
              ),
              child: IconButton(
                icon: const Icon(Icons.add_call, color: Colors.white),
                onPressed: () => _showAddNumberDialog(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModeButton({
    required String text,
    required VoidCallback onTap,
    required Color color1,
    required Color color2,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [color1, color2]),
          borderRadius: BorderRadius.circular(18),
          boxShadow: const [
            BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
          ],
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600),
        ),
      ),
    );
  }
}
