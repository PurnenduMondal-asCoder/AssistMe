import 'package:flutter/material.dart';
import 'pick_mode_page.dart';
import 'text_to_speech_page.dart';
import 'voice_recording_page.dart';
import 'symbol_communicatiom.dart';

void main() {
  runApp(const CommunicationAssistantApp());
}

class CommunicationAssistantApp extends StatelessWidget {
  const CommunicationAssistantApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Communication Assistant',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: const Color(0xFFE6F7FF),
        fontFamily: 'Arial',
      ),
      home: const PickModePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  Widget buildOptionTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 3,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(icon, color: Colors.green, size: 30),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        style: const TextStyle(
                            fontSize: 14, color: Colors.black54)),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('COMMUNICATION ASSISTANT'),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: Column(
        children: [
          const SizedBox(height: 10),
          buildOptionTile(
            icon: Icons.volume_up,
            title: 'Text to Speech',
            subtitle: 'Convert written text into spoken words',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const TextToSpeechScreen()),
            ),
          ),
          buildOptionTile(
            icon: Icons.grid_view,
            title: 'Symbol Communication',
            subtitle: 'Communicate using symbols and visuals',
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SymbolCommunication()),
            ),
          ),
          buildOptionTile(
            icon: Icons.mic,
            title: 'Voice Recordings',
            subtitle: 'Pre-recorded messages for quick communication',
            onTap: () => Navigator.push(
              context,
             MaterialPageRoute(builder: (_) => const VoiceRecordingPage()),
            ),
          ),
        ],
      ),
    );
  }
}
