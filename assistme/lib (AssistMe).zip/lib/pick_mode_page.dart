import 'package:flutter/material.dart';
import 'main.dart'; // To access HomePage
import 'assist_mode_page.dart'; // We'll create this next

class PickModePage extends StatelessWidget {
  const PickModePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE1F8FF),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text(
                'PICK YOUR MODE',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF002C5F),
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 48),
              _buildModeButton(
                context,
                text: 'Assist Mode',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AssistModePage()),
                ),
              ),
              const SizedBox(height: 24),
              _buildModeButton(
                context,
                text: 'Standard Mode',
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const HomePage()),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModeButton(BuildContext context,
      {required String text, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: const [
            BoxShadow(
              color: Colors.black26,
              blurRadius: 6,
              offset: Offset(0, 2),
            ),
          ],
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w600,
            color: Color(0xFF002C5F),
          ),
        ),
      ),
    );
  }
}
