import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:flutter/services.dart';

class SymbolCommunication extends StatefulWidget {
  const SymbolCommunication({super.key});

  @override
  State<SymbolCommunication> createState() => _SymbolCommunicationState();
}

class _SymbolCommunicationState extends State<SymbolCommunication> {
  final FlutterTts flutterTts = FlutterTts();

  List<Map<String, dynamic>> symbols = [
    {"icon": Icons.local_drink, "label": "Drink Water", "message": "I want to drink water"},
    {"icon": Icons.restaurant, "label": "Eat Food", "message": "I am hungry"},
    {"icon": Icons.bed, "label": "Sleep", "message": "I want to sleep"},
    {"icon": Icons.home, "label": "Home", "message": "I want to go to my home"},
    {"icon": Icons.medical_services, "label": "Medicine", "message": "I need my medicine"},
    {"icon": Icons.wc, "label": "Toilet", "message": "I need to use the toilet"},
    {"icon": Icons.smart_toy_rounded, "label": "Headache", "message": "I have a headache"},
    {"icon": Icons.healing, "label": "Pain", "message": "I am in pain"},
    {"icon": Icons.headphones, "label": "Music", "message": "I want to listen to music"},
    {"icon": Icons.tv, "label": "TV", "message": "Please turn on the TV"},
    {"icon": Icons.thermostat, "label": "I'm Cold", "message": "I am feeling cold"},
    {"icon": Icons.wb_sunny, "label": "I'm Hot", "message": "I am feeling hot"},
    {"icon": Icons.sentiment_satisfied, "label": "I'm Happy", "message": "I am happy"},
    {"icon": Icons.sentiment_dissatisfied, "label": "I'm Sad", "message": "I am feeling sad"},
    {"icon": Icons.directions_walk, "label": "Go Outside", "message": "I want to go outside"},
    {"icon": Icons.people, "label": "Come Here", "message": "Can someone come here?"},
    {"icon": Icons.favorite, "label": "Thank You", "message": "Thank you very much"},
    {"icon": Icons.call, "label": "Call Help", "message": "Please call someone for help"},
  ];

  void speak(String message) async {
    await flutterTts.setLanguage("en-US");
    await flutterTts.setPitch(1.0);
    await flutterTts.speak(message);

    HapticFeedback.selectionClick();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Saying: "$message"'),
        duration: const Duration(seconds: 2),
        backgroundColor: Colors.lightBlue.shade200,
      ),
    );
  }

  IconData getIconForLabel(String label) {
    final lowerLabel = label.toLowerCase();
    if (lowerLabel.contains('mango')) return Icons.local_grocery_store;
    if (lowerLabel.contains('apple')) return Icons.apple;
    if (lowerLabel.contains('doctor')) return Icons.medical_services;
    if (lowerLabel.contains('music')) return Icons.music_note;
    if (lowerLabel.contains('food')) return Icons.restaurant;
    if (lowerLabel.contains('drink')) return Icons.local_drink;
    if (lowerLabel.contains('toilet')) return Icons.wc;
    if (lowerLabel.contains('pain')) return Icons.healing;
    if (lowerLabel.contains('sleep')) return Icons.bed;
    if (lowerLabel.contains('home')) return Icons.home;
    if (lowerLabel.contains('medicine')) return Icons.medical_services;
    if (lowerLabel.contains('headache')) return Icons.smart_toy_rounded;
    if (lowerLabel.contains('tv')) return Icons.tv;
    if (lowerLabel.contains('cold')) return Icons.thermostat;
    if (lowerLabel.contains('hot')) return Icons.wb_sunny;
    if (lowerLabel.contains('happy')) return Icons.sentiment_satisfied;
    if (lowerLabel.contains('sad')) return Icons.sentiment_dissatisfied;
    if (lowerLabel.contains('outside')) return Icons.directions_walk;
    if (lowerLabel.contains('come')) return Icons.people;
    if (lowerLabel.contains('thank')) return Icons.favorite;
    if (lowerLabel.contains('call')) return Icons.call;
    return Icons.star; // fallback icon
  }

  void showAddSymbolDialog() {
    final labelController = TextEditingController();
    final messageController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Add New Symbol'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: labelController,
              decoration: const InputDecoration(labelText: 'Label (e.g., Call Doctor)'),
            ),
            TextField(
              controller: messageController,
              decoration: const InputDecoration(labelText: 'Message (e.g., Please call my doctor)'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final label = labelController.text.trim();
              final message = messageController.text.trim();
              if (label.isNotEmpty && message.isNotEmpty) {
                setState(() {
                  symbols.add({
                    "icon": getIconForLabel(label),
                    "label": label,
                    "message": message,
                  });
                });
                Navigator.pop(context);
              }
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFE1F8FF),
      appBar: AppBar(
        title: const Text(
          'Symbol Communication',
          style: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.bold,
            color: Color(0xFF003366),
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black87,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 18,
          crossAxisSpacing: 18,
          children: symbols.map((symbol) {
            return InkWell(
              onTap: () => speak(symbol["message"]),
              borderRadius: BorderRadius.circular(20),
              child: Ink(
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFFB2EBF2), Color(0xFFE0F7FA)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.shade300,
                      blurRadius: 8,
                      offset: const Offset(2, 4),
                    ),
                  ],
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Colors.white,
                      ),
                      child: Icon(symbol["icon"], size: 40, color: Colors.teal),
                    ),
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        symbol["label"],
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF004D40),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          }).toList(),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: showAddSymbolDialog,
        backgroundColor: Colors.teal,
        child: const Icon(Icons.add),
      ),
    );
  }
}
