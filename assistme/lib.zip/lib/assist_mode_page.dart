import 'package:flutter/material.dart';

class AssistModePage extends StatelessWidget {
  const AssistModePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Assist Mode',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Color(0xFF003366),
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.black87,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Welcome to Assist Mode',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Learn how to use the app step by step. Below are the main features and their usage instructions:',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 20),
            _buildStepCard(
              stepTitle: "1. Text-to-Speech",
              description:
                  "Convert your typed text into clear, spoken words. Navigate to the Text-to-Speech page, type your message, and tap 'Speak'.",
              icon: Icons.text_fields,
            ),
            _buildStepCard(
              stepTitle: "2. Voice Recording",
              description:
                  "Record your voice and save it with a label for easy identification. You can play back recordings from the list.",
              icon: Icons.mic,
            ),
            _buildStepCard(
              stepTitle: "3. Pre-Recorded Messages",
              description:
                  "Quickly access and play pre-recorded messages for faster communication.",
              icon: Icons.playlist_play,
            ),
            _buildStepCard(
              stepTitle: "4. Navigation",
              description:
                  "Easily switch between modes using the main menu. All features are just a tap away.",
              icon: Icons.navigation,
            ),
            const SizedBox(height: 20),
            const Text(
              'Get Started!',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 5),
            const Text(
              'Follow the steps and explore each mode to enhance your communication experience.',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required String stepTitle,
    required String description,
    required IconData icon,
  }) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8),
      elevation: 3,
      child: ListTile(
        leading: Icon(icon, color: const Color(0xFF003366)),
        title: Text(
          stepTitle,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        subtitle: Text(description),
      ),
    );
  }
}
